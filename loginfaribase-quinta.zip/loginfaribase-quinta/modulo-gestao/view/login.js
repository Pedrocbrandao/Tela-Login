import {Component} from 'react'
import {View, Text, TextInput, Button, ActivityIndicator} from 'react-native'

import firebase from 'firebase'
import {estilos} from '../css/estilos'

export default class Login extends Component{
  constructor(){
    super();
    this.state = {
      email: '',
      password: '',
      isLoading: false
    }
  }

  atualizarValor = (valor, props) =>{
    const state = this.state
    state[props] = valor
    this.setState(state)
  }

  userLogin = ()=>{
    if(this.state.email === '' || this.state.password === ''){
      alert("Usuario ou senha invalida!")
      this.setState({isLoading: false})
    } else {
      this.setState({isLoading: false})
      firebase.auth().signInWithEmailAndPassword(this.state.email, this.state.password).then((response)=>{
        this.setState({
          email:'',
          password: '',
          isLoading: false
        })
        this.props.navigation.navigate('TelaHome')
      }).catch((error)=>{
        messageError: error
      })
    }
  }
 

  render(){  
    if(this.state.isLoading){
      <View>
        <ActivityIndicator size='large' color='#3740fe' />
      </View>
    }
  
  return(
    <View style={estilos.container}>
      <TextInput style={estilos.input} placeholder = 'Usuario' value = {this.state.email} onChangeText={(val) => this.atualizarValor(val, 'email')}/>
      <TextInput style={estilos.input} placeholder = 'Senha' value = {this.state.password} onChangeText={(val) => this.atualizarValor(val, 'password')}
      secureTextEntry = {true} maxLength={8}/>

      <Button title='Logar' onPress={()=>this.userLogin()}/>

      <Text onPress={() => this.props.navigation.navigate('TelaCadastro')} style={estilos.textLink}>
        Não tem conta? Clique aqui para Cadastrar!
      </Text>
    </View>
  )
  }
}