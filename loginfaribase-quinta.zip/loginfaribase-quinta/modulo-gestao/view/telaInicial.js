import React, { Component } from 'react';
import { View, TextInput, Button, ActivityIndicator, Text } from 'react-native';
import firebase from 'firebase';
import { estilos } from '../css/estilos';
import {Card, Icon} from 'react-native-elements'

export default class TelaInicial extends Component {
  constructor() {
    super();
    this.state = {
      uid: firebase.auth().currentUser.uid,
      nome: firebase.auth().currentUser.displayName,
      idade: '',
      matricula: '',
      isLoading: false,
    };

    this.db = firebase.firestore();
  }

  cadastrarDados = () => {
    if (this.state.idade === '' || this.state.matricula === '') {
      alert('Favor digitar os valores solicitados!');
      this.setState({ isLoading: false });
    } else {
      const document = this.state.matricula.toString();
      const data = {
        nome: this.state.nome,
        matricula: this.state.matricula,
        idade: this.state.idade,
      };

      this.db
        .collection('perfilUsuario')
        .doc(document)
        .set(data)
        .then(() => {
          alert('Dados foram salvos com sucesso!');
          this.setState({
            uid: '',
            nome: '',
            matricula: '',
            idade: '',
            isLoading: false,
          });
        })
        .catch((error) => {
          alert('Houve erro ao salvar dados');
          this.setState({
            messageErro: error,
          });
        });
    }
  };

  sair = () => {
    firebase.auth().signOut().then((resp)=>{
      alert("Logout efetuado com sucesso!")
    }).catch((error)=>{
      alert("Erro ao efetuar Logout!" + error)
    })
  }

  atualizarValor = (valor, props) => {
    const state = this.state;
    state[props] = valor;
    this.setState(state);
  };

  render() {
    if (this.state.isLoading) {
      return (
        <View style={estilos.container}>
          <ActivityIndicator size="large" color="#3740fe" />
        </View>
      );
    }

    return (
      <View style={estilos.container}>
        <Text style={estilos.titulo}> Atualizarção do perfil</Text>
        <View style={estilos.botao}>
      <Card>
        <Card.Title>Cadastro do Perfil</Card.Title>
        <Card.Divider />
        <Card.Image source={require('../img/iconPerfil.png')}/>
      </Card>
      </View>
        <TextInput
          placeholder={'Nome'}
          value={this.state.nome}
          onChangeText={(valor) => this.atualizarValor(valor, 'nome')}
          style={estilos.input}
        />

        <TextInput
          placeholder={'Idade'}
          value={this.state.idade}
          onChangeText={(valor) => this.atualizarValor(valor, 'idade')}
          style={estilos.input}
        />

        <TextInput
          placeholder={'Matricula'}
          value={this.state.matricula}
          onChangeText={(valor) => this.atualizarValor(valor, 'matricula')}
          style={estilos.input}
        />
        <View style={estilos.botao}>
          <Button title="Cadastrar" onPress={() => this.cadastrarDados()}/>
          <Button title="Sair" onPress={() => this.sair()} />
        </View>
      </View>
    );
  }
}
