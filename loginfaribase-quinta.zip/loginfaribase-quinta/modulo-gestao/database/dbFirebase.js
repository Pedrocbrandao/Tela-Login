const firebaseConfig = {
  apiKey: "AIzaSyAaFDXyoZ487EAgpS_SzQs-DyNY43jNMi4",
  authDomain: "projetofirebase01-quinta.firebaseapp.com",
  projectId: "projetofirebase01-quinta",
  storageBucket: "projetofirebase01-quinta.appspot.com",
  messagingSenderId: "826348667751",
  appId: "1:826348667751:web:4b1252e71c63c177c7e5c2"
};

export default firebaseConfig;