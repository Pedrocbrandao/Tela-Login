import {NavigationContainer} from '@react-navigation/native'
import {createStackNavigator} from '@react-navigation/stack'

import firebase from 'firebase'
import firebaseConfig from './modulo-gestao/database/dbFirebase'
import Login from './modulo-gestao/view/login'
import Cadastro from './modulo-gestao/view/cadastro'
import TelaInicial from './modulo-gestao/view/telaInicial'

const Stack = createStackNavigator()

function Menu(){
  return(
    <Stack.Navigator initialRouteName = 'TelaLogin' screenOptions = {{headerStyle:{
      backgroundColor: 'green'
    },
    headerTitleAlign: 'center',
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeigth: 'bold'
    }
    }}>
      <Stack.Screen name = 'TelaLogin' component={Login} options={{title:"Tela de login"}}/>
      <Stack.Screen name = 'TelaCadastro' component={Cadastro} options={{title:"Tela de Cadastro"}}/>
      <Stack.Screen name = 'TelaHome' component={TelaInicial} options={{title:"Tela de Cadastro do perfil"}}/>
    </Stack.Navigator>
  )
}

export default function App(){
  if(!firebase.apps.length){
    firebase.initializeApp(firebaseConfig)
  }

  return(
    <NavigationContainer>
      <Menu/>
    </NavigationContainer>
  )
}